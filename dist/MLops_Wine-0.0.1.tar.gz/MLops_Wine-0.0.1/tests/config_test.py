

def test_generic():
    a = 8
    b = 8
    assert a== b