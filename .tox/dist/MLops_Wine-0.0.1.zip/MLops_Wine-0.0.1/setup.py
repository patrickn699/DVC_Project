from setuptools import setup,find_packages

setup(
    name="MLops_Wine",
    version = '0.0.1',
    description = 'Wine prediction using MLops',
    author = 'Patrick&N',
    packages = find_packages(),
    license = 'MIT'

)